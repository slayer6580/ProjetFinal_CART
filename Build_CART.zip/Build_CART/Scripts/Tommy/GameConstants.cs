using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameConstants
{
	public const float BASE_ADD_FORCE = 1000;
	public const float DEADZONE = 0.1f;
}

