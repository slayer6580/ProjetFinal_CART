# DiscountDelirium

## Alex (placement des items et des boîtes)
- 'A' sur la manette: Prendre des items en appuyant 
- '+' et '-' sur lee clavier: Retirer ajouter des boîtes 
- 'O' pour retirer un item.
- 'Y' pour vider le panier.

## Tommy (déplacements)
- R2 pour avancer
- L2 Reculer (et drifter)

## Chirstopher (encaisser les articles, victoire et defaite)
1- Prenez des items dans les étagère.
2- Se déplacer vers la zone rouge.

## Remi (System d'équilibre de la tour et perte d'objets)
1- '+' au clavier pour ajouter des boîtes.
2- Ajoutez plus que 3 boîtes et la quatrième qui sort du panier.
4- Appuyez 'K' ou 'L' pour enclencher les DebugCart.
5- Résultat, la boîte s'envole du panier.

6- Rajoutez de boîtes pour en avoir qui dépasse du panier.
7- Prenez des items dans les étagère.
8- Appuyez 'K' ou 'L' pour enclencher les DebugCart.
9- Résultat, les items et les boîtes s'envolent.

10- Pour activer les springs il faut peser 'N' ou 'M'.
11- Une fois spring sont selectioné traves les debug logs, 
    Les boîtes qi sortent du panier devrais avoir des springs.
    Les springs n'offraient pas le résultat désiré, donc peu développé
    Je dois étandre cette tâche pour les remplacer par des hinjes.
